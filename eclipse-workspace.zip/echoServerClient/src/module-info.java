/**
 * 
 */
/**
 * @author donny
 *
 */
module echoServerClient {
}