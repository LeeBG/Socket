package echoServerClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class SocketClient {
	private Socket clientSocket;
	private PrintWriter printWriter;
	private BufferedReader bufferedReader;
	private Scanner scanner;
	private Integer port;
	
	public static void main(String[] args) {
		new SocketClient();
	}
	
	public SocketClient() {
		port = 18981;
		init(port);
	}
	
	public void init(int port) {
		try {
			clientSocket = new Socket("localhost",port);
			System.out.println("Server Connect...");
			
			bufferedReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));// 서버로 부터 데이터를 받아올 준비
			printWriter = new PrintWriter(clientSocket.getOutputStream()); // 서버로 데이터 보낸 준비
			
			scanner = new Scanner(System.in);
			
			String sendData = "";
			
			while(!sendData.equals("exit") && sendData.getBytes().length <= 100) {
				System.out.print("to Server:");
				System.out.print("보낼데이터를 입력하세요[제한 100byte]: ");
				sendData = scanner.next();	  // 보낼 내용을 입력받는다.
				printWriter.println(sendData);// 보낼 내용을 서버로 보낸다.
				printWriter.flush(); // 프린트라이터 메모리를 초기화 시켜서 내부에 있는 데이터를 서버로 전송한다.
				System.out.println("from Server." + bufferedReader.readLine()); // 서버로 부터 받은 데이터를 표기한다.
			}
			
			System.out.println("클라이언트를 종료합니다.");
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			scanner.close();
			try {
				clientSocket.close();
				bufferedReader.close();
				printWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
