package echoServerClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SocketServer {
	private ServerSocket serverSocket;		// 서버 소켓 
	private BufferedReader bufferedReader; // 클라이언트로 부터 받은 메시지를 읽기 위한 버퍼 메모리
	private PrintWriter printWriter; // 클라이언트에게 메시지를 전달
	private Socket clientSocket; // 클라이언트 소켓
	private Integer port; // 포트번호

	public SocketServer() {
		port = 18981;
		init(port);
	}

	public void init(int port) {
		try {
			serverSocket = new ServerSocket(port); // 현재 IP로 port를 포트번호로 사용하여 서버를 오픈
			System.out.println("Server is Ready");
			System.out.println("connect client...");
			
			clientSocket = serverSocket.accept(); // 클라이언트의 연결 요청을 수락
			System.out.println("Client has accepted from :" +clientSocket.getInetAddress().toString()); // ip주소 확인
			
			bufferedReader =  new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));// 클라이언트로부터 데이터를 읽기 위한 준비
			printWriter = new PrintWriter(clientSocket.getOutputStream());	// 클라이언트로부터 데이터를 보낼 준비
			
			String readData = ""; // 클라이언트로 부터 읽을 데이터를 저장할 변수
			
			while ((readData = bufferedReader.readLine()) != null) { 
			    System.out.println("from Client>" + readData);
			    printWriter.println(readData); // 읽은 메시지를 그대로 클라이언트에 다시 보냄
			    printWriter.flush();           // 프린트라이터 메모리를 초기화 시켜야 데이터가 보내짐
			}
			System.out.println("서버를 종료합니다.");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				serverSocket.close();
				clientSocket.close();
				bufferedReader.close();
				printWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		new SocketServer();
	}

}
